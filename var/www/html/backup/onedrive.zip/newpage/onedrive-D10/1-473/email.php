<?php


$email = array("phish@digidragonsctf.com");  //PUT YOUR EMAIL HERE!!!
$telegramTOKEN = "12345678:227de24c5e70d582e1cfecb1c57105ff"; //PUT YOUR TELEGRAM TOKEN HERE!!! PS : Hex value is your flag
$telegramID = "12345678";   //PUT YOUR ID HERE!!!


?>
